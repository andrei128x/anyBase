
import math
import sys
import os
import re

# ultima pozitie cunoscuta



# citeste numele fisierului din lista de parametri
def readInput():
	if( len(sys.argv)>1 ):
		assert os.path.exists(sys.argv[1]), "I did not find the file at, "+str(user_input)
		return sys.argv[1]
	else:
		return ""
		
# citeste continutul fisierului si calculeaza lungimea traseului de parcurs pentru fiecare bloc
def readFile( fileName ):

	lastX = 0
	lastY = 0
	lastZ = 0

	currX = 0
	currY = 0
	currZ = 0

	fh = open(fileName, "r+")

	for line in fh:
		# print word, coord
		command = re.findall(r"[gG][\s]?[01]*", line)
		coord_list = re.findall(r"[xXyYzZ][0-9.]*", line)
		
		for coord in coord_list:
			if( ("x" in coord ) or ("X" in coord) ):
				currX = float(coord[1:])
			if( ("y" in coord ) or ("Y" in coord) ):
				currY = float(coord[1:])
			if( ("z" in coord ) or ("Z" in coord) ):
				currZ = float(coord[1:])

		distance = math.sqrt( (currX-lastX)**2 + (currY-lastY)**2 + (currZ-lastZ)**2)
		print line, command, coord_list

		lastX = currX
		lastY = currY
		lastZ = currZ
		
		
	fh.close()

readFile( readInput() )
		